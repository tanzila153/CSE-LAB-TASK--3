# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


"""
In search.py, you will implement generic search algorithms which are called by
Pacman agents (in searchAgents.py).
"""

import util
from util import*
class SearchProblem:
    """
    This class outlines the structure of a search problem, but doesn't implement
    any of the methods (in object-oriented terminology: an abstract class).

    You do not need to change anything in this class, ever.
    """

    def getStartState(self):
        """
        Returns the start state for the search problem.
        """
        util.raiseNotDefined()

    def isGoalState(self, state):
        """
          state: Search state

        Returns True if and only if the state is a valid goal state.
        """
        util.raiseNotDefined()

    def getSuccessors(self, state):
        """
          state: Search state

        For a given state, this should return a list of triples, (successor,
        action, stepCost), where 'successor' is a successor to the current
        state, 'action' is the action required to get there, and 'stepCost' is
        the incremental cost of expanding to that successor.
        """
        util.raiseNotDefined()

    def getCostOfActions(self, actions):
        """
         actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.
        The sequence must be composed of legal moves.
        """
        util.raiseNotDefined()


def tinyMazeSearch(problem):
    """
    Returns a sequence of moves that solves tinyMaze.  For any other maze, the
    sequence of moves will be incorrect, so only use this for tinyMaze.
    """
    from game import Directions
    s = Directions.SOUTH
    w = Directions.WEST
    return  [s, s, w, s, w, w, s, w]

def depthFirstSearch(problem):
    """
    Search the deepest nodes in the search tree first.
    """
    import time
    start_time = time.time()  # Start timing the search

    currPath = []  # The path leading to the current state
    currState = problem.getStartState()  # Start state of the problem

    if problem.isGoalState(currState):  # Check if the start state is also the goal
      print("DFS total explore time (microseconds):", (time.time() - start_time) * 1000000)  
      return currPath

    frontier = util.Stack()  # DFS uses a stack for the frontier
    frontier.push((currState, currPath))
    explored = set()

    while not frontier.isEmpty():
        currState, currPath = frontier.pop()

        if currState in explored:
            continue

        if problem.isGoalState(currState):
            print("DFS total explore time (microseconds):", (time.time() - start_time) * 1000000)
            return currPath

        explored.add(currState)

        for successor, action, _ in problem.getSuccessors(currState):
            if successor not in explored:
                frontier.push((successor, currPath + [action]))

    print("DFS total explore time (microseconds):", (time.time() - start_time) * 1000000)
    return []  # Return an empty path if no solution is found

def uniformCostSearch(problem):
    """
    Search the node of least total cost first.
    """
    from util import PriorityQueue
    import time
    start_time = time.time()  # Start timing the search

    currState = problem.getStartState()
    frontier = PriorityQueue()  # UCS uses a priority queue for the frontier
    frontier.push((currState, []), 0)  # Start state with priority 0
    explored = set()
    costSoFar = {currState: 0}  # Keep track of the cost to reach each state

    while not frontier.isEmpty():
        currState, currPath = frontier.pop()

        if currState in explored:
            continue

        if problem.isGoalState(currState):
            print("UCS total explore time (microseconds):", (time.time() - start_time) * 1000000)
            return currPath

        explored.add(currState)

        for successor, action, stepCost in problem.getSuccessors(currState):
            newCost = costSoFar[currState] + stepCost

            if successor not in explored or newCost < costSoFar.get(successor, float('inf')):
                costSoFar[successor] = newCost
                frontier.push((successor, currPath + [action]), newCost)

    print("UCS total explore time (microseconds):", (time.time() - start_time) * 1000000)
    return []  # Return an empty path if no solution is found

def breadthFirstSearch(problem):
    """
    Search the shallowest nodes in the search tree first.
    """
    import time
    start_time = time.time()  # Start timing the search

    currPath = []  # The path that is popped from the frontier in each loop
    currState = problem.getStartState()  # The state(position) that is popped for the frontier in each loop

    if problem.isGoalState(currState):  
      print("DFS total explore time (microseconds):", (time.time() - start_time) * 1000000)  
      return currPath

    frontier = util.Queue()  # BFS uses a queue for the frontier
    frontier.push((currState, currPath))  # Insert just the start state, in order to pop it first
    explored = set()

    while not frontier.isEmpty():
        currState, currPath = frontier.pop()  # Popping a state and the corresponding path

        if currState in explored:
            continue

        if problem.isGoalState(currState):
            print("BFS total explore time (microseconds):", (time.time() - start_time) * 1000000)
            return currPath

        explored.add(currState)

        for successor, action, _ in problem.getSuccessors(currState):
            if successor not in explored:
                frontier.push((successor, currPath + [action]))

    print("BFS total explore time (microseconds):", (time.time() - start_time) * 1000000)
    return []  # Return an empty path if no solution is found

def nullHeuristic(state, problem=None):
    """
    A heuristic function estimates the cost from the current state to the nearest
    goal in the provided SearchProblem.  This heuristic is trivial.
    """
    return 0

def aStarSearch(problem, heuristic=nullHeuristic):
    """Search the node that has the lowest combined cost and heuristic first."""
    "*** YOUR CODE HERE ***"
    util.raiseNotDefined()


# Abbreviations
bfs = breadthFirstSearch
dfs = depthFirstSearch
astar = aStarSearch
ucs = uniformCostSearch